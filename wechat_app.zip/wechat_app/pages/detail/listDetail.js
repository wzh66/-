// pages/detail/listDetail.js
let datas=require('../../data/list.js');
Page({
  /**
   * 页面的初始数据
   */
  data:{
    detailObj:{},
    index:null,
    isCollected:false,
    isMusicPlay:false
  },
  isFs(){
    wx.showActionSheet({
      itemList: [
        "分享到朋友圈","分享到QQ","分享给微信好友"
        ],
    })
  },
  musicTap(){
    let isMusicPlay=!this.data.isMusicPlay;
    this.setData({
      isMusicPlay
    });
    if(isMusicPlay){
      let {dataUrl,title}=this.data.detailObj.music;
      wx.playBackgroundAudio({
        dataUrl,
        title
      })
    }
    else{
      wx.pauseBackgroundAudio();
    }
  },
  isC(){
      console.log(this);
      let isCollected=!this.data.isCollected;
      this.setData({
        isCollected
      });
      let title=isCollected?"收藏成功":"取消收藏";
      wx.showToast({
        title,
        icon:"success"
      });
      let {index}=this.data;
      wx.getStorage({
        key: 'isCollected',
        success:(datas) =>{
          let obj=datas.data;
          console.log(datas,typeof datas);
          obj[index]=isCollected;
          wx.setStorage({
            key: 'isCollected',
            data: obj,
            success:()=>{
              console.log('缓存成功')
            }
          })
        },
      })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options);
      let index=options.index;
      this.setData({
        detailObj:datas.listData[index],
        index:index
      });
      let detailS=wx.getStorageSync('isCollected');
      console.log(detailS);
      if(!detailS){
        wx.setStorageSync('isCollected',{})
      }
      if(detailS[index]){
        this.setData({
          isCollected:true
        })
      }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})