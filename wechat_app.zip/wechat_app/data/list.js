let listData = [
  {
    date: '03 11 2018',
    title: '在美国eBay被炒到每盒一万刀的四川辣酱 究竟是个啥？',
    detail_img: '/images/data_s01.jpg',
    avatar: 'http://img.jituwang.com/uploads/allimg/151003/258203-1510030RP894.jpg',
    detail_content: '起因是魔幻+脑洞的高人气动画《瑞克和莫蒂》第三季时隔两年后在美国凯旋。在第一集，我们可爱的瑞克老爷爷就叫嚣着要吃1998年麦当劳为电影《花木兰》做宣传而发明的四川辣酱（又称木兰酱），“有多少来多少”，并给予了极高的评价——他称这是支持他的唯一动力，哪怕再花9季时间，再等个97年，也要吃到这款已经绝版的四川辣酱',
    headImgSrc: '/images/data_s01.jpg',
    author: '今天要吃什么 ',
    dataTime: '24time',
    detail_love_image1: '/images/data/chat.png',
    detail_love_image2: '/images/data/view.png',
    love_count: 66,
    attention_count: 80,
    detail: '最近，美国人民疯了，因为四川辣酱。',
    music: {
      dataUrl: 'http://up.mcyt.net/down/46100.mp3', // 音乐链接
      title: 'IF-Ken Arai',   // 音乐标题
      coverImgUrl: 'https://gss1.bdstatic.com/-vo3dSag_xI4khGkpoWK1HF6hhy/baike/w%3D268%3Bg%3D0/sign=2c25cb31d954564ee565e33f8be5fbbf/10dfa9ec8a13632707a13511958fa0ec08fac740.jpg',
    },
    postId: 0
  },
  {

    date: '05 11 2018',
    title: '2020款奔驰CLA猎装车曝光',
    detail_img: '/images/data_s02.jpg',
    avatar: 'http://img.jituwang.com/uploads/allimg/151003/258203-1510030RP894.jpg',
    detail_content: '起先奔驰决定不再更新CLS的时候，有传言说奔驰会砍掉CLA车型，此次Caradvice曝光的谍照推翻了这一传言。由于还没有投入量产，我们还不能完全确定CLA轿跑将会与A级掀背及轿车具体有何不同，不过从目前轿跑和猎装车的谍照来看，新一代CLA看上去将会像小号的CLS。图中新款CLA采用奔驰新款单镀铬条格栅设计(目前新款A级CLS都采用了这款格栅) ，尾部采用新款轿跑车型尾灯设计。',
    headImgSrc: '/images/data_01.jpg',
    author: '三木说车',
    dataTime: '24time',
    detail_love_image1: '/images/icon/chat.png',
    detail_love_image2: '/images/icon/view.png',
    love_count: 66,
    attention_count: 80,
    detail: '起先奔驰决定不再更新CLS',
    music: {
      dataUrl: 'http://www.ytmp3.cn/down/50395.mp3', // 音乐链接
      title: 'Main theme',   // 音乐标题
      coverImgUrl: 'http://p2.music.126.net/9xcnX1Rvqx-Wl2obH1XSTw==/8887352487401227.jpg?param=130y130',
    },
    postId: 1
  },
  {

    date: '05 11 2018',
    title: '放弃燃油车的理由? 试驾比亚迪全新一代宋EV',
    detail_img: '/images/data_s03.jpg',
    avatar: 'http://a.hiphotos.baidu.com/zhidao/wh%3D450%2C600/sign=601bfdb2fbf2b211e47b8d4affb0490e/e824b899a9014c081e25b3640a7b02087af4f4d1.jpg',
    detail_content: '上山最好的季节，怕就是此时此刻的深秋了。“停车坐爱枫林晚，霜叶红于二月花。”古人既有秋季上山赏红叶的习惯，这两天我也得到了一次赏叶的机会，和全新一代的宋EV 500来了一段“红叶之旅”。两年前，我试驾过比亚迪的三款电动车，秦EV300、E5和E6，前两款属于A级轿车，E6则是一款城市SUV车型。对于当时的秦EV和E5，两者驾驶感受层面差距不大，采用了相同的218匹马力电机，直观感受是大功率电机带来的推背感，如果在抓地力稍差的路面，“地板油”急加速还会出现轻微烧胎的现象，这是同价位汽油车所不能比拟的。而那款SUV--E6开起来更像是在开船，忽忽悠悠算不太讨喜。这一次有机会试驾到比亚迪全新的纯电动SUV，我内心还是比较期待的，一是来看看比亚迪在这两年的变化，二是想知道如今的电动车能否让我有购买的欲望。',
    headImgSrc: '/images/data_03.jpg',
    author: '跟我视驾',
    dataTime: '24time',
    detail_love_image1: '/images/icon/chat.png',
    detail_love_image2: '/images/icon/view.png',
    love_count: 66,
    attention_count: 80,
    detail: '上山最好的季节',
    music: {
      dataUrl: 'http://www.ytmp3.cn/down/50355.mp3', // 音乐链接
      title: '听海',   // 音乐标题
      coverImgUrl: 'http://p2.music.126.net/ezlY3g3Xllrp-Fh33YzKyA==/7893393976819956.jpg?param=130y130',
    },
    postId: 2
  }
];

module.exports = { listData };