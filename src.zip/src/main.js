// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import Home from './components/Home.vue'
import Car from './components/Car.vue'
import Page1 from './components/Page1.vue'
import Page2 from './components/Page2.vue'
import Page3 from './components/Page3.vue'
import Page4 from './components/Page4.vue'
import Page5 from './components/Page5.vue'
import Page6 from './components/Page6.vue'
import Page7 from './components/Page7.vue'
import Page8 from './components/Page8.vue'
import Product_list from './components/Product_list.vue'
import Product_detail from './components/Product_detail.vue'
import VueRouter from 'vue-router'
import $ from 'jquery'
import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap/dist/js/bootstrap.min'
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';


 Vue.use(VueRouter);
Vue.use(ElementUI);
Vue.config.productionTip = false;

const routes = [
  { path: '/home', component: Home },
  { path: '/car', component: Car },
  { path: '/product_list', component: Product_list,children:[
    {
      path: '/page1',
      name: 'Page1',
      component: Page1
    },
    {
      path: '/page2',
      name: 'Page2',
      component: Page2
    },
    {
      path: '/page3',
      name: 'Page3',
      component: Page3
    }, {
  path: '/page4',
    name: 'Page4',
  component: Page4
},{
      path: '/page5',
      name: 'Page5',
      component: Page5
    },
    {
      path: '/page6',
      name: 'Page6',
      component: Page6
    },
    {
      path: '/page7',
      name: 'Page7',
      component: Page7
    },
    {
      path: '/page8',
      name: 'Page8',
      component: Page8
    }
  ],redirect: '/page1'
  },
  { path: '/product_detail', component: Product_detail },
  { path: '*', redirect: '/home' }
]


const router=new VueRouter({
  mode:'history',
  linkActiveClass:'active',
  routes
})

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>',
    render: h => h(App)
})
