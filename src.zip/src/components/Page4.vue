<!--suppress ALL -->
<template>
  <div id="page4">
    <section class="nav-list">
    <div class="header-title">
      <h3><span>精选智能穿戴</span></h3>
    </div>
      <div class="b">
        <ul>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/华为儿童手表 3 Pro.jpg" width="63" height="64"/></p>
              <p class="p-name">华为儿童手表 3 Pro</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/荣耀手环4 标准版.png" width="63" height="64"/></p>
              <p class="p-name">荣耀手环4 标准版</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/华为手环 B5.png" width="63" height="64"/></p>
              <p class="p-name">华为手环 B5</p>
            </a>
          </li>
        </ul>
        <ul>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/荣耀手环3.png" width="63" height="64"/></p>
              <p class="p-name">荣耀手环3</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/HUAWEI WATCH 2 Pro.jpg" width="63" height="64"/></p>
              <p class="p-name">HUAWEI WATCH 2 Pro</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/荣耀手环4 Running版.jpg" width="63" height="64"/></p>
              <p class="p-name">荣耀手环4 Running版</p>
            </a>
          </li>
        </ul>
        </div>
      </section>
    <section class="nav-list">
      <div class="header-title">
        <h3><span>智能穿戴分类</span></h3>
      </div>
      <div class="b">
        <ul>
          <li style="margin-bottom: 80px">
            <a href="#">
              <p class="p-img"><img src="../../images/手环.jpg" width="63" height="64"/></p>
              <p class="p-name">手环</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/手表.jpg" width="63" height="64"/></p>
              <p class="p-name">手表</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/VR.jpg" width="63" height="64"/></p>
              <p class="p-name">VR</p>
            </a>
          </li>
        </ul>
      </div>
    </section>
  </div>

</template>

<style lang="scss">
  ul{
    list-style: none;
  }
  .header-title{
    text-align:center;
    padding: .55rem 0 .6rem;
    h3{
      display: inline-flex;
      padding: 0 2rem;
      span{
        font-size:16px;
        line-height: 1.2;
        font-weight: bold;
        background-color: #fff;
        z-index: 2;
        padding: 0 .5rem;
      }
    }
  }
  .nav-list ul{
    width:100%;
    margin:0;
    padding:0;
  li{
    width: 33%;
    float:left;
  a{
    text-align: center;
    text-decoration:none;
    cursor:pointer;
    color:black;
  .p-name{
    line-height: 16px;
    color: #333;
  }
  }
  }
  }
</style>

<script>
  export default{
    data(){
      return{
      }
    }
  }
</script>
