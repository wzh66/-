<!--suppress ALL -->
<template>
  <div id="page5">
    <section class="nav-list">
    <div class="header-title">
      <h3><span>精选智能家居</span></h3>
    </div>
      <div class="b">
        <ul>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/荣耀路由 X2.png" width="63" height="64"/></p>
              <p class="p-name">荣耀路由 X2</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/华为子母路由 Q2.jpg" width="63" height="64"/></p>
              <p class="p-name">华为子母路由 Q2</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/荣耀路由2S.jpg" width="63" height="64"/></p>
              <p class="p-name">荣耀路由2S</p>
            </a>
          </li>
        </ul>
        </div>
      </section>
    <section class="nav-list">
      <div class="header-title">
        <h3><span>智能家居分类</span></h3>
      </div>
      <div class="b">
        <ul>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/荣耀路由 X2.png" width="63" height="64"/></p>
              <p class="p-name">路由器</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/子母分布式路由.jpg" width="63" height="64"/></p>
              <p class="p-name">子母/分布式路由</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/电力猫wifi放大器.jpg" width="63" height="64"/></p>
              <p class="p-name">电力猫/wifi放大器</p>
            </a>
          </li>
        </ul>
        <ul>
          <li style="margin-bottom: 80px">
            <a href="#">
              <p class="p-img"><img src="../../images/华为随行WiFi 2.jpg" width="63" height="64"/></p>
              <p class="p-name">随行wifi</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/电视盒子.jpg" width="63" height="64"/></p>
              <p class="p-name">电视盒子</p>
            </a>
          </li>
        </ul>
      </div>
    </section>
  </div>

</template>

<style lang="scss">
  ul{
    list-style: none;
  }
  .header-title{
    text-align:center;
    padding: .55rem 0 .6rem;
    h3{
      display: inline-flex;
      padding: 0 2rem;
      span{
        font-size:16px;
        line-height: 1.2;
        font-weight: bold;
        background-color: #fff;
        z-index: 2;
        padding: 0 .5rem;
      }
    }
  }
  .nav-list ul{
    width:100%;
    margin:0;
    padding:0;
  li{
    width: 33%;
    float:left;
  a{
    text-align: center;
    text-decoration:none;
    cursor:pointer;
    color:black;
  .p-name{
    line-height: 16px;
    color: #333;
  }
  }
  }
  }
</style>

<script>
  export default{
    data(){
      return{
      }
    }
  }
</script>
