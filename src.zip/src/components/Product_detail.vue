<!--suppress ALL -->
<template>
  <div id="detail">
    <header class="header">产品详情</header>
    <div class="detail_box">
    <swiper :options="swiperOption">
      <swiper-slide><img src="../../images/Mate20-1.png"/></swiper-slide>
      <swiper-slide><img src="../../images/Mate20-2.png"/></swiper-slide>
      <swiper-slide><img src="../../images/Mate20-3.png"/></swiper-slide>
      <swiper-slide><img src="../../images/Mate20-4.png"/></swiper-slide>
      <swiper-slide><img src="../../images/Mate20-5.png"/></swiper-slide>
      <swiper-slide><img src="../../images/Mate20-6.png"/></swiper-slide>
      <swiper-slide><img src="../../images/Mate20-7.png"/></swiper-slide>
      <swiper-slide><img src="../../images/Mate20-8.png"/></swiper-slide>
    </swiper>
    </div>
    <div class="p-name">
    <h1>
      <span>HUAWEI Mate 20 <span id="version">6GB+64GB</span> 全网通版（<span id="color">亮黑色</span>)</span>
    </h1>
      <p id="price">￥3999</p>
    </div>
    <div class="p-area-discount">
      <p class="p-discount">
      <span>支持分期</span>
      <span>分期免息</span>
      <span>赠送积分</span>
      </p>
    </div>
    <div class="p-content">
      <dl>
      <dt><label>颜色</label></dt>
      <dd id="colorList" class="colorList">
        <a class="selected"><span>亮黑色</span></a>
        <a><span>宝石蓝</span></a>
        <a><span>樱粉金</span></a>
        <a><span>翡冷翠</span></a>
        <a><span>极光色</span></a>
      </dd>
      </dl>
      <dl>
        <dt><label>版本</label></dt>
        <dd id="versionList" class="versionList">
          <a class="selected"><span>全网通 6GB+64GB</span></a>
          <a><span>全网通 6GB+128GB</span></a>
        </dd>
      </dl>
      <dl>
        <dt><label>数量</label></dt>
        <dd class="num">
          <el-input-number v-model="num1"  :min="1" :max="10"></el-input-number>
        </dd>
      </dl>
    </div>
    <section class="proList" style="margin-bottom: 70px">
        <div class="p-home">
          <img src="../../images/home.png" height="30" width="30"/>
          <p>首页</p>
        </div>
      <div class="p-home">
        <img src="../../images/car.png" height="30" width="30"/>
        <p>购物车</p>
      </div>
      <div class="p-home">
        <img src="../../images/service.png" height="30" width="30"/>
        <p>客服</p>
      </div>
      <div class="p-car">
        <span>加入购物车</span>
      </div>
      <div class="p-buy">
        <span>立即购买</span>
      </div>
    </section>
  </div>
</template>

<style lang="scss">
  .header{
    height: 4.4rem;
    background: #ebcdb1;
    color: #fff;
    line-height: 4.4rem;
    text-align: center;
  a{
    color:#fff;
    text-decoration: none;
  }
  }
  .detail_box img{
    width: 300px;
    height: 300px;
   max-width: 100%;
    vertical-align: top;
    margin: 0 50px;
  }
  .p-name
  {
    padding-left:.9em;
   h1{
    font-size: 1.1em;
    line-height: 1.3em;
    font-weight: bold;
  }
   p{
    color: red;
     font-size: 1.4em;
     line-height: normal;
   }
  }
  .p-area-discount{
    width: 100%;
    height: 40px;
    background-color:#eaeaea;
    .p-discount {
      padding-left:20px;
      span {
    font-size: .55em;
    color: #888;
    line-height: 3em;
    display: inline-block;
    padding: 0 1.82em 0 1.182em;
    background: url("../../images/right.png") no-repeat left center;
    background-size: .91em .91em;
  }
  }
  }
  .p-content{
    padding:0 .8em;
    dl{
      padding: .3em 0;
      border-bottom: 1px solid #eaeaea;
      display:flex;
      dt {
        width: 2.4em;
        float: none;
        padding-top: .35em;
        padding-left:.35em;
    label {
    font-size: .8em;
    line-height: 1.4;
    color: #888;
    display: block;
  }
  }
  .colorList{
    width: 100%;
    -webkit-box-flex: 1;
    flex-shrink: 1;
    overflow: hidden;
    padding-left:20px;
    a{
      text-align: left;
      max-width: 100%;
      font-size: 0.9em;
      height: 1.95em;
      line-height: 1.95em;
      padding: 0 1em;
      border-radius: 1em;
      vertical-align: text-bottom;
      min-width: 1em;
      border: 1px solid #b2b2b2;
      display: inline-block;
      margin: .3em .5em .3em 0;
      background-color: #fff;
    }
  .selected{
    border-color: #ca151e;
    color: #ca151e;
  }
  }
  .versionList{
    width: 100%;
    -webkit-box-flex: 1;
    flex-shrink: 1;
    overflow: hidden;
    padding-left:20px;
  a{
    text-align: left;
    max-width: 100%;
    font-size: 0.9em;
    height: 1.95em;
    line-height: 1.95em;
    padding: 0 1em;
    border-radius: 1em;
    vertical-align: text-bottom;
    min-width: 1em;
    border: 1px solid #b2b2b2;
    display: inline-block;
    margin: .3em .5em .3em 0;
    background-color: #fff;
  }
  .selected{
    border-color: #ca151e;
    color: #ca151e;
  }
  }
  .num{
    width: 100%;
    -webkit-box-flex: 1;
    flex-shrink: 1;
    overflow: hidden;
    padding-left:20px;
  }
    }
  }
  .proList{
    width: 100%;
    max-width: 720px;
    background-color: #fff;
    border-top: 1px solid #eaeaea;
    border-bottom: 1px solid #eaeaea;
    display:flex;
    .p-home{
     width: 65px;
      height: 55px;
      padding: .2em 0;
      border-right: 1px solid #eaeaea;
      box-sizing: border-box;
      img{
        display: block;
        margin: 0 auto;
      }
      p{
        color:#888 ;
        text-align: center;
        font-size: .5em;
      }
    }
    .p-car{
      width: 105px;
      background-color: #f17f00;
      span{
        font-size: 1em;
        display: block;
        padding-top:10px;
        color: #fff;
        text-align: center;
      }
    }
    .p-buy{
      width: 105px;
      background-color:#ca151e ;
  span{
    font-size: 1em;
    display: block;
    padding-top:10px;
    color: #fff;
    text-align: center;
  }
    }

  }

</style>

<script>
  import 'swiper/dist/css/swiper.css'
  import { swiper, swiperSlide } from 'vue-awesome-swiper'
  export default {
    data(){
      return {
        num1: 1,
        //设置属性
        swiperOption:{
          //显示分页
          pagination: {
            el: '.swiper-pagination',
            clickable:true
          },
          //切换模式  横屏或者竖屏
          // direction : 'vertical',
          //设置自动播放速度
          autoplay: {
            disableOnInteraction: false,
            delay:4000
          },
          //开启无限循环
          loop:true,
          //设置点击箭头
          paginationClickable :true,
          prevButton:'.swiper-button-prev',
          nextButton:'.swiper-button-next',
          //设置同屏显示的数量，默认为1，使用auto是随意的意思。
          slidesPerView:1,
          //开启鼠标滚轮控制Swiper切换。可设置鼠标选项，或true使用默认值。
          mousewheel:true ,
          //默认为false，普通模式：slide滑动时只滑动一格，并自动贴合wrapper，设置为true则变为free模式，slide会根据惯性滑动可能不止一格且不会贴合。
          // freeMode:true
        }
      }
    },
    components:{
      swiper,
      swiperSlide
    }
  }
  window.onload=function () {
    var  clist=document.getElementById('colorList').getElementsByTagName('a');
    var  vlist=document.getElementById('versionList').getElementsByTagName('a');
    var color=document.getElementById('color');
    var price=document.getElementById('price');
    var version=document.getElementById('version');
    function changeClass(curIndex) {
      for(var i=0;i<clist.length;i++){
        clist[i].className="";
      }
      clist[curIndex].className="selected";
    }
    function changeClass2(curIndex) {
      for(var j=0;j<vlist.length;j++){
        vlist[j].className="";
      }
      vlist[curIndex].className="selected";
    }
    function changeText(curIndex) {
      switch(curIndex){
        case '0':color.innerText="亮黑色";break;
        case '1':color.innerText="宝石蓝";break;
        case '2':color.innerText="樱粉金";break;
        case '3':color.innerText="翡冷翠";break;
        case '4':color.innerText="极光色";break;
      }
    }
    function changeText2(curIndex) {
      switch(curIndex){
        case '0':version.innerText="6GB+64GB";
          price.innerHTML="￥3999";
          break;
        case '1':version.innerText="6GB+128GB";
          price.innerHTML="￥4499";
          break;
      }
    }
    for(var i=0;i<clist.length;i++){
      clist[i].id=i;
      clist[i].onclick=function () {
        changeClass(this.id);
        changeText(this.id);
      }
    }
    for(var j=0;j<vlist.length;j++){
      vlist[j].id=j;
      vlist[j].onclick=function () {
        changeClass2(this.id);
        changeText2(this.id);
      }
    }
  }
</script>
