<!--suppress ALL -->
<template>
  <div id="home">
      <header class="header">首页</header>
    <!--避免头部遮挡，而加的空白 -->
    <div class="white"></div>
    <el-input
      placeholder="HUAWEI Mate 20"
      prefix-icon="el-icon-search"
      v-model="input">
    </el-input>
    <div class="bannerbox">
    <swiper :options="swiperOption">
      <swiper-slide><img src="../../images/image1.jpg" height="304" width="720"/></swiper-slide>
      <swiper-slide><img src="../../images/nova3.jpg" height="304" width="720"/></swiper-slide>
      <swiper-slide><img src="../../images/华为Mate20.jpg" height="304" width="720"/></swiper-slide>
      <swiper-slide><img src="../../images/华为儿童手表.png" height="304" width="720"/></swiper-slide>
      <swiper-slide><img src="../../images/华为配件.jpg" height="304" width="720"/></swiper-slide>
      <swiper-slide><img src="../../images/畅享9plus.jpg" height="304" width="720"/></swiper-slide>
    </swiper>
    </div>
    <div class="img">
      <ul>
        <li class="li_logo left">
          <div class="logo_01 ">
          </div>
          <span><a href="#">优质配件</a></span>
        </li>
        <li class="li_logo left">
          <div class="logo_02 ">
          </div>
          <span><a href="#">会员领券</a></span>
        </li>
        <li class="li_logo left">
          <div class="logo_03 ">
          </div>
          <span><a href="#">畅享新品</a></span>
        </li>
        <li class="li_logo left">
          <div class="logo_04 ">
          </div>
          <span><a href="#">以旧换新</a></span>
        </li>
        <li class="li_logo left">
          <div class="logo_05 ">
          </div>
          <span><a href="#">免费登记</a></span>
        </li>
      </ul>
    </div>
    <div class="channel">
      <ul>
        <li>
          <a href="#"><img src="../../images/HUAWEI Mate 20.png" height="104" width="188"/></a>
        </li>
        <li>
          <a href="#"><img src="../../images/HUAWEIP20.jpg" height="104" width="188"/></a>
        </li>
      </ul>
      </div>
    <section class="channel_list">
      <div class="h"><h2>手机</h2></div>
      <div class="b">
        <ul>
          <li>
            <a href="product_detail">
              <p class="p-img"><img src="../../images/Mate 20.png" width="83" height="83"/></p>
              <p class="p-name">HUAWEI Mate 20</p>
              <p class="p-promotion">99元订金预订</p>
              <p class="p-price">￥8888</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/华为畅享9plus.jpg" width="83" height="83"/></p>
              <p class="p-name">华为畅享9 Plus</p>
              <p class="p-promotion">新品上市 赠好礼</p>
              <p class="p-price">￥1499</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/华为畅享MAX.jpg" width="83" height="83"/></p>
              <p class="p-name">华为畅享 MAX</p>
              <p class="p-promotion">新品首销 赠好礼</p>
              <p class="p-price">￥1699</p>
            </a>
          </li>
        </ul>
        <ul>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/Mate 20.png" width="83" height="83"/></p>
              <p class="p-name">HUAWEI Mate 20</p>
              <p class="p-promotion">99元订金预订</p>
              <p class="p-price">￥8888</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/华为畅享9plus.jpg" width="83" height="83"/></p>
              <p class="p-name">华为畅享9 Plus</p>
              <p class="p-promotion">新品上市 赠好礼</p>
              <p class="p-price">￥1499</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/华为畅享MAX.jpg" width="83" height="83"/></p>
              <p class="p-name">华为畅享 MAX</p>
              <p class="p-promotion">新品首销 赠好礼</p>
              <p class="p-price">￥1699</p>
            </a>
          </li>
        </ul>
        <ul>
          <li style="margin-bottom: 80px">
            <a href="#">
              <p class="p-img"><img src="../../images/Mate 20.png" width="83" height="83"/></p>
              <p class="p-name">HUAWEI Mate 20</p>
              <p class="p-promotion">99元订金预订</p>
            <p class="p-price">￥8888</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/华为畅享9plus.jpg" width="83" height="83"/></p>
              <p class="p-name">华为畅享9 Plus</p>
              <p class="p-promotion">新品上市 赠好礼</p>
              <p class="p-price">￥1499</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/华为畅享MAX.jpg" width="83" height="83"/></p>
              <p class="p-name">华为畅享 MAX</p>
              <p class="p-promotion">新品首销 赠好礼</p>
              <p class="p-price">￥1699</p>
            </a>
          </li>
        </ul>
      </div>
    </section>
    </div>
</template>
<style lang="scss">
  *{
    margin: 0;
    padding: 0;
  }
  a{color:#2d374b;text-decoration:none}
  .left{
    float: left;
  }
  li{
    list-style: none;
  }
  .header{
    height:4.0rem;
    width: 100%;
    background-color: #f3e0c2;
    z-index:10;
    position: fixed;
    color: white;
    display: block;
    line-height:4.0rem;
    cursor: pointer;
    text-align: center;
  a{
    color:#fff;
  }
  }
  .white{
    margin:0;
    padding:0;
    border:0;
    width: 100%;
    height: 65px;
  }
  .bannerbox img{
    width: 100%;
    border: 0;
    max-width: 100%;
    height: auto;
    vertical-align: top;
    max-height: 400px;
  }
  .img{
    height: 70px;
     }
  .li_logo {
    margin:0 3px;
  span {
    margin: 0 5px;
  a {
    text-decoration: none;
  }
  }
  }
  @mixin adjust{
    height: 40px;
    width: 40px;
    margin: 0 14px;
  }
  .logo_01{
    background: url(../../images/logo_small_02.png) no-repeat;
    background-position: -200px 0;
    @include adjust();
  }
  .logo_02{
     background: url(../../images/logo_small_01.png) no-repeat;
     background-position: -120px 0;
    @include adjust();
   }
  .logo_03{
    background: url(../../images/logo_small_02.png) no-repeat;
    background-position: -80px 0;
    @include adjust();
  }
   .logo_04{
    background: url(../../images/logo_small_01.png) no-repeat;
    background-position: -40px 0;
    @include adjust();
  }
  .logo_05{
    background: url(../../images/logo_small_02.png) no-repeat;
    background-position: -160px 0;
    @include adjust();
  }
  .channel{
    background-color: #f5f5f5;
    height:125px;
    ul{
      li{
        float: left;
        margin: 5px;
      }
    }
  }
  .channel_list
    .h {
    height: 30px;
  h2 {
    font-size: 20px;
    line-height: 26px;
    padding: 0 1.15em;
    font-weight: normal;
    margin-top: 10px;
  }
  }
  .b{
    ul{
      width: 100%;
      li{
        width: 33%;
        float: left;
        border-top:1px solid #eaeaea ;
        border-right: 1px solid #eaeaea;
        border-bottom: 1px solid #eaeaea;
        a{
          text-align: center;
        text-decoration:none;
        cursor:pointer;
          .p-img{
            padding-top: 20px;
          }
          .p-name{
            line-height: 16px;
            color: #333;
          }
          .p-promotion{
            font-size: 12px;
           padding-top:-10px;
            color: #bbb;
          }
          .p-price{
            padding-top: -10px;
            color: #ca151e;
          }
        }
      }
    }
  }
</style>

<script>
  import 'swiper/dist/css/swiper.css'
  import { swiper, swiperSlide } from 'vue-awesome-swiper'
  export default {
    data(){
      return {
        input:"",
        //设置属性
        swiperOption:{
          //显示分页
          pagination: {
            el: '.swiper-pagination',
            clickable:true
          },
          //切换模式  横屏或者竖屏
          // direction : 'vertical',
          //设置自动播放速度
          autoplay: {
            disableOnInteraction: false,
            delay:4000
          },
          //开启无限循环
          loop:true,
          //设置点击箭头
          paginationClickable :true,
          prevButton:'.swiper-button-prev',
          nextButton:'.swiper-button-next',
          //设置同屏显示的数量，默认为1，使用auto是随意的意思。
          slidesPerView:1,
          //开启鼠标滚轮控制Swiper切换。可设置鼠标选项，或true使用默认值。
          mousewheel:true ,
          //默认为false，普通模式：slide滑动时只滑动一格，并自动贴合wrapper，设置为true则变为free模式，slide会根据惯性滑动可能不止一格且不会贴合。
          // freeMode:true
        }
      }
    },
    components:{
      swiper,
      swiperSlide
    }
  }

</script>
