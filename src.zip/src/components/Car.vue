<template>
  <div id="car">
    <section class="car_list">
      <div class="h"><h2>购物车</h2></div>
      <div class="bg">
        <p><img src="../../images/car.png" height="30" width="30"/><span>购物车中还没有商品，赶紧选购吧</span></p>
      </div>
    </section>
    <section class="hot_list">
      <div class="h"><h2>热销推荐</h2></div>
      <div class="b">
        <ul>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/Mate 20.png" width="98" height="98"/></p>
              <p class="p-name">HUAWEI Mate 20</p>
              <p class="p-promotion">99元订金预订</p>
              <p class="p-price">￥8888</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/华为畅享9plus.jpg" width="98" height="98"/></p>
              <p class="p-name">华为畅享9 Plus</p>
              <p class="p-promotion">新品上市 赠好礼</p>
              <p class="p-price">￥1499</p>
            </a>
          </li>
        </ul>
        <ul>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/Mate 20.png" width="83" height="83"/></p>
              <p class="p-name">HUAWEI Mate 20</p>
              <p class="p-promotion">99元订金预订</p>
              <p class="p-price">￥8888</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/华为畅享9plus.jpg" width="83" height="83"/></p>
              <p class="p-name">华为畅享9 Plus</p>
              <p class="p-promotion">新品上市 赠好礼</p>
              <p class="p-price">￥1499</p>
            </a>
          </li>
        </ul>
        <ul>
          <li style="margin-bottom: 80px">
            <a href="#">
              <p class="p-img"><img src="../../images/Mate 20.png" width="83" height="83"/></p>
              <p class="p-name">HUAWEI Mate 20</p>
              <p class="p-promotion">99元订金预订</p>
              <p class="p-price">￥8888</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/华为畅享9plus.jpg" width="83" height="83"/></p>
              <p class="p-name">华为畅享9 Plus</p>
              <p class="p-promotion">新品上市 赠好礼</p>
              <p class="p-price">￥1499</p>
            </a>
          </li>
        </ul>
      </div>
    </section>
  </div>
</template>

<style lang="scss">
  .car_list .h {
    height: 40px;
  h2 {
    font-size: 20px;
    line-height: 26px;
    padding: 0 1.15em;
    font-weight: normal;
    margin-top: 10px;
  }
  }
  .bg{
    height: 150px;
    width: 100%;
    background-color: rgba(0, 0, 0, 0.11);
    p{
      text-align: center;
      padding: 50px;
      span{
        color: #888;
        padding-left: 10px;
        font-size: 17px;
      }
    }
  }
  .hot_list
  .h {
    height: 30px;
  h2 {
    font-size: 20px;
    line-height: 26px;
    padding: 0 1.15em;
    font-weight: normal;
    margin-top: 10px;
  }
  }
  .b{
  ul{
    width: 100%;
  list-style:none;
    margin:0;
    padding:0;
  li{
    width: 50%;
    float: left;
    border-top:1px solid #eaeaea ;
    border-right: 1px solid #eaeaea;
    border-bottom: 1px solid #eaeaea;
  a{
    text-align: center;
    text-decoration:none;
    cursor:pointer;
  .p-img{
    padding-top: 20px;
  }
  .p-name{
    line-height: 16px;
    color: #333;
  }
  .p-promotion{
    font-size: 12px;
    padding-top:-10px;
    color: #bbb;
  }
  .p-price{
    padding-top: -10px;
    color: #ca151e;
  }
  }
  }
  }
  }

</style>

<script>

</script>
