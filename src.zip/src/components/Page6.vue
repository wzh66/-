<!--suppress ALL -->
<template>
  <div id="page6">
    <section class="nav-list">
    <div class="header-title">
      <h3><span>精选专属配件</span></h3>
    </div>
      <div class="b">
        <ul>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/HUAWEI Mate 20 Pro 硅胶保护壳.png" width="63" height="64"/></p>
              <p class="p-name">HUAWEI Mate 20 Pro 硅胶保护壳</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/荣耀V10 PU磁吸保护套.jpg" width="63" height="64"/></p>
              <p class="p-name">荣耀V10 PU磁吸保护套</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/HUAWEI P20智能视窗保护套.jpg" width="63" height="64"/></p>
              <p class="p-name">HUAWEI P20智能视窗保护套</p>
            </a>
          </li>
        </ul>
        </div>
      </section>
    <section class="nav-list">
      <div class="header-title">
        <h3><span>专属配件分类</span></h3>
      </div>
      <div class="b">
        <ul>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/保护壳.jpg" width="63" height="64"/></p>
              <p class="p-name">保护壳</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/保护套.jpg" width="63" height="64"/></p>
              <p class="p-name">保护套</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/贴膜.jpg" width="63" height="64"/></p>
              <p class="p-name">贴膜</p>
            </a>
          </li>
        </ul>
        <ul>
          <li style="margin-bottom: 80px">
            <a href="#">
              <p class="p-img"><img src="../../images/盒子专属配件.jpg" width="63" height="64"/></p>
              <p class="p-name">盒子专属配件</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/表带.jpg" width="63" height="64"/></p>
              <p class="p-name">表带</p>
            </a>
          </li>
        </ul>
      </div>
    </section>
  </div>

</template>

<style lang="scss">
  ul{
    list-style: none;
  }
  .header-title{
    text-align:center;
    padding: .55rem 0 .6rem;
    h3{
      display: inline-flex;
      padding: 0 2rem;
      span{
        font-size:16px;
        line-height: 1.2;
        font-weight: bold;
        background-color: #fff;
        z-index: 2;
        padding: 0 .5rem;
      }
    }
  }
  .nav-list ul{
    width:100%;
    margin:0;
    padding:0;
  li{
    width: 33%;
    float:left;
  a{
    text-align: center;
    text-decoration:none;
    cursor:pointer;
    color:black;
  .p-name{
    line-height: 16px;
    color: #333;
  }
  }
  }
  }
</style>

<script>
  export default{
    data(){
      return{
      }
    }
  }
</script>
