<!--suppress ALL -->
<template>
  <div id="page7">
    <section class="nav-list">
    <div class="header-title">
      <h3><span>精选配件</span></h3>
    </div>
      <div class="b">
        <ul>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/华为智能体脂秤.jpg" width="63" height="64"/></p>
              <p class="p-name">华为智能体脂秤</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/荣耀xSport 运动蓝牙耳机.jpg" width="63" height="64"/></p>
              <p class="p-name">荣耀xSport 运动蓝牙耳机</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/华为移动电源.jpg" width="63" height="64"/></p>
              <p class="p-name">华为移动电源</p>
            </a>
          </li>
        </ul>
        </div>
      </section>
    <section class="nav-list">
      <div class="header-title">
        <h3><span>通用配件分类</span></h3>
      </div>
      <div class="b">
        <ul>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/移动电源.jpg" width="63" height="64"/></p>
              <p class="p-name">移动电源</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/耳机.jpg" width="63" height="64"/></p>
              <p class="p-name">耳机</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/充电器线材.jpg" width="63" height="64"/></p>
              <p class="p-name">充电器/线材</p>
            </a>
          </li>
        </ul>
        <ul>
          <li style="margin-bottom: 80px">
            <a href="#">
              <p class="p-img"><img src="../../images/自拍杆支架.jpg" width="63" height="64"/></p>
              <p class="p-name">自拍杆/支架</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/音箱.jpg" width="63" height="64"/></p>
              <p class="p-name">音箱</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/U盘存储卡.jpg" width="63" height="64"/></p>
              <p class="p-name">U盘/存储卡</p>
            </a>
          </li>
        </ul>
      </div>
    </section>
  </div>

</template>

<style lang="scss">
  ul{
    list-style: none;
  }
  .header-title{
    text-align:center;
    padding: .55rem 0 .6rem;
    h3{
      display: inline-flex;
      padding: 0 2rem;
      span{
        font-size:16px;
        line-height: 1.2;
        font-weight: bold;
        background-color: #fff;
        z-index: 2;
        padding: 0 .5rem;
      }
    }
  }
  .nav-list ul{
    width:100%;
    margin:0;
    padding:0;
  li{
    width: 33%;
    float:left;
  a{
    text-align: center;
    text-decoration:none;
    cursor:pointer;
    color:black;
  .p-name{
    line-height: 16px;
    color: #333;
  }
  }
  }
  }
</style>

<script>
  export default{
    data(){
      return{
      }
    }
  }
</script>
