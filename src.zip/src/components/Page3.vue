<!--suppress ALL -->
<template>
  <div id="page3">
    <section class="nav-list">
    <div class="header-title">
      <h3><span>精选笔记本</span></h3>
    </div>
      <div class="b">
        <ul>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/HUAWEI MateBook X Pro.png" width="63" height="64"/></p>
              <p class="p-name">HUAWEI MateBook X Pro</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/荣耀MagicBook.png" width="63" height="64"/></p>
              <p class="p-name">荣耀MagicBook</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/HUAWEI MateBook D.jpg" width="63" height="64"/></p>
              <p class="p-name">HUAWEI MateBook D</p>
            </a>
          </li>
        </ul>
        </div>
      </section>
    <section class="nav-list">
      <div class="header-title">
        <h3><span>精选平板</span></h3>
      </div>
      <div class="b">
        <ul>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/荣耀平板5.png" width="63" height="64"/></p>
              <p class="p-name">荣耀平板5</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/华为平板 M5 10.8英寸.jpg" width="63" height="64"/></p>
              <p class="p-name">华为平板 M5 10.8英寸</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/荣耀Waterplay.jpg" width="63" height="64"/></p>
              <p class="p-name">荣耀Waterplay</p>
            </a>
          </li>
        </ul>
      </div>
    </section>
    <section class="nav-list">
      <div class="header-title">
        <h3><span>笔记本&平板分类</span></h3>
      </div>
      <div class="b">
        <ul>
          <li style="margin-bottom: 80px">
            <a href="#">
              <p class="p-img"><img src="../../images/平板电脑.jpg" width="63" height="64"/></p>
              <p class="p-name">平板电脑</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/笔记本电脑.jpg" width="63" height="64"/></p>
              <p class="p-name">笔记本电脑</p>
            </a>
          </li>
          <li>
            <a href="#">
              <p class="p-img"><img src="../../images/笔记本配件.jpg" width="63" height="64"/></p>
              <p class="p-name">笔记本配件</p>
            </a>
          </li>
        </ul>
      </div>
    </section>
  </div>

</template>

<style lang="scss">
  ul{
    list-style: none;
  }
  .header-title{
    text-align:center;
    padding: .55rem 0 .6rem;
    h3{
      display: inline-flex;
      padding: 0 2rem;
      span{
        font-size:16px;
        line-height: 1.2;
        font-weight: bold;
        background-color: #fff;
        z-index: 2;
        padding: 0 .5rem;
      }
    }
  }
  .nav-list ul{
    width:100%;
    margin:0;
    padding:0;
  li{
    width: 33%;
    float:left;
  a{
    text-align: center;
    text-decoration:none;
    cursor:pointer;
    color:black;
  .p-name{
    line-height: 16px;
    color: #333;
  }
  }
  }
  }
</style>

<script>
  export default{
    data(){
      return{
      }
    }
  }
</script>
