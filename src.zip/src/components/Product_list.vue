<!--suppress ALL -->
<template>
  <div id="list">
    <header class="header">产品列表</header>
    <div class="white"></div>
    <el-row :gutter="10">
      <el-col :span="9" style="position: fixed">
        <div >
          <el-menu default-active="1" class="el-menu-vertical-demo" style="min-height: 200px" @select="handleSelect">
            <el-menu-item index="1"><i class="el-icon-phone"></i>华为手机</el-menu-item>
            <el-menu-item index="2"><i class="el-icon-mobile-phone"></i>荣耀手机</el-menu-item>
            <el-menu-item index="3"><i class="el-icon-star-on"></i>笔记本&平板</el-menu-item>
            <el-menu-item index="4"><i class="el-icon-setting"></i>智能穿戴</el-menu-item>
            <el-menu-item index="5"><i class="el-icon-menu"></i>智能家居</el-menu-item>
            <el-menu-item index="6"><i class="el-icon-service"></i>专属配件</el-menu-item>
            <el-menu-item index="7"><i class="el-icon-view"></i>通用配件</el-menu-item>
            <el-menu-item index="8"><i class="el-icon-goods"></i>生态产品</el-menu-item>
          </el-menu>
        </div>
      </el-col>
      <el-col :span="15">
        <div style="margin-top:10px;position: relative;top:0;left: 150px;">
          <router-view></router-view>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<style lang="scss">
  .white{
    margin:0;
    padding:0;
    border:0;
    width: 100%;
    height: 65px;
  }
  .header{
    height:4.0rem;
    width: 100%;
    background-color: #f3e0c2;
    z-index:10;
    position: fixed;
    color: white;
    display: block;
    line-height:4.0rem;
    cursor: pointer;
    text-align: center;
  a{
    color:#fff;
    text-decoration: none;
  }
  }
</style>

<script>
  export default {
    methods: {
      handleSelect(key){
        switch(key){
          case '1':
            return this.$router.push('/page1');
            break;
          case '2':
            this.$router.push('/page2')
            break;
          case '3':
            this.$router.push('/page3')
            break;
          case '4':
            this.$router.push('/page4')
            break;
          case '5':
            this.$router.push('/page5')
            break;
          case '6':
            this.$router.push('/page6')
            break;
          case '7':
            this.$router.push('/page7')
            break;
          case '8':
            this.$router.push('/page8')
            break;
        }
      }
    }
  }
</script>
