<template>
  <div id="app">
    <footer class="footer">
   <router-link class="nav-item" to="/home"><img src="../images/首页.png" height="68" width="81"/></router-link>
    <router-link class="nav-item" to="/product_list"><img src="../images/分类.png" height="68" width="81"/></router-link>
    <router-link class="nav-item" to="/car"><img src="../images/购物车.png" height="68" width="81"/></router-link>
    </footer>
    <router-view></router-view>
  </div>
</template>
<script>
</script>

<style lang="scss">
  .footer {
    height: 4.4rem;
    width: 100%;
    background: #f3e0c2;
    color: #fff;
    display: block;
    z-index: 10;
    position: fixed;
    bottom: 0rem;
    line-height: 4.4rem;
    text-align: center;
    a{
      color:#fff;
      padding:0 20px;
      text-decoration: none;
    }
  }

</style>
